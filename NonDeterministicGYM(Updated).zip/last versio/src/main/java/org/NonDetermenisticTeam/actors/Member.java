package org.NonDetermenisticTeam.actors;

import org.NonDetermenisticTeam.Documentable;
import org.NonDetermenisticTeam.events.Event;
import org.NonDetermenisticTeam.utility.WorkoutLog;

import java.util.ArrayList;

// Inheritance: Member extends Person
// Interfaces: implements Documentable
public final class Member extends Person implements Documentable {

    public enum MemberType {
        BASIC,
        PREMIUM,
        VIP
    }

    // Exception Handling with Custom Exceptions
    public static class InvalidMembershipType extends Exception {
        public InvalidMembershipType() {
            super("InvalidMembershipType : Insufficient membership level for specified event");
        }
    }

    // Encapsulation: private fields
    private final MemberType type;
    private final ArrayList<Event> joinedEvents = new ArrayList<Event>();
    // Composition: Member "has" a list of WorkoutLogs
    private final ArrayList<WorkoutLog> workoutHistory = new ArrayList<WorkoutLog>();

    public Member(String name, String surname, Integer age, Gender gender, MemberType type) {
        super(name, surname, age, gender);
        this.type = type;
    }

    // Loading constructor — preserves saved ID
    public Member(int loadedId, String name, String surname, Integer age, Gender gender, MemberType type) {
        super(loadedId, name, surname, age, gender);
        this.type = type;
    }

    public MemberType getMembershipType() {
        return type;
    }

    public ArrayList<Event> getJoinedEvents() {
        return joinedEvents;
    }

    public void joinEvent(Event event) throws Event.DuplicateEventException, InvalidMembershipType, Event.EventTimeConflictsException {
        // Check if the member is already in the event
        if (joinedEvents.contains(event)) {
            throw new Event.DuplicateEventException();
        }

        // Check if member has the minimum membership level required
        if (event.getMinimumMembershipLevel().ordinal() > this.getMembershipType().ordinal()) {
            throw new InvalidMembershipType();
        }

        // Check if member has another event clashing with new one
        for (Event e : joinedEvents) {
            if (e.getDate().isEqual(event.getDate())) {
                if (e.getTimeInterval().intersects(event.getTimeInterval())) {
                    throw new Event.EventTimeConflictsException();
                }
            }
        }
        joinedEvents.add(event);
    }

    public void leaveEvent(Event event) {
        joinedEvents.remove(event);
    }

    // --- Workout History ---

    public void logWorkout(WorkoutLog log) {
        workoutHistory.add(log);
    }

    public ArrayList<WorkoutLog> getWorkoutHistory() {
        return workoutHistory;
    }

    // Method Overriding: Documentable.getInfo()
    @Override
    public String getInfo() {
        return "Member: " + name + " " + surname
                + " | ID: " + id
                + " | Type: " + type
                + " | Age: " + age
                + " | Events: " + joinedEvents.size()
                + " | Workouts: " + workoutHistory.size();
    }

    @Override
    public String toString() {
        return name + " " + surname + " (" + type + ")";
    }
}
