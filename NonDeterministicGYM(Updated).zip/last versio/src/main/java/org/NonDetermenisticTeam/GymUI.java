package org.NonDetermenisticTeam;

import org.NonDetermenisticTeam.actors.*;
import org.NonDetermenisticTeam.actors.GroupSessionRoom;
import org.NonDetermenisticTeam.actors.Person.Gender;
import org.NonDetermenisticTeam.events.*;
import org.NonDetermenisticTeam.events.Event;
import org.NonDetermenisticTeam.utility.*;
import org.NonDetermenisticTeam.actors.PersonalTrainer.ShiftConflictException;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class GymUI extends JFrame {

    private final Management management;

    // Table models
    private DefaultTableModel memberTableModel, trainerTableModel, roomTableModel;
    private DefaultTableModel groupSessionTableModel, gymEventTableModel, trainerEventTableModel;
    private DefaultTableModel workoutTableModel, equipmentTableModel;

    // Combo boxes that need refresh on tab switch
    private JComboBox<String> gsRoomCB, gsMemberCB;
    private JComboBox<String> geRoomCB, geMemberCB;
    private JComboBox<String> teMemberCB, teTrainerCB, teRoomCB;
    private JComboBox<String> wlMemberCB;

    public GymUI(Management management) {
        this.management = management;
        setTitle("NonDetermenistic Gym — Fitness Center Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 700);
        setLocationRelativeTo(null);

        // Save on close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                DataPersistence.saveAll(management);
            }
        });

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Members", buildMembersPanel());
        tabs.addTab("Trainers", buildTrainersPanel());
        tabs.addTab("Rooms", buildRoomsPanel());
        tabs.addTab("Group Sessions", buildGroupSessionPanel());
        tabs.addTab("Gym Bookings", buildGymEventPanel());
        tabs.addTab("Trainer Sessions", buildTrainerEventPanel());

        // Workout Log + Used Equipments as sub-tabs
        JTabbedPane workoutTabs = new JTabbedPane();
        workoutTabs.addTab("Workout Log", buildWorkoutPanel());
        workoutTabs.addTab("Used Equipments", buildEquipmentPanel());
        tabs.addTab("Workout & Equipment", workoutTabs);

        add(tabs);

        // Refresh combo boxes when switching tabs
        tabs.addChangeListener(e -> {
            int idx = tabs.getSelectedIndex();
            if (idx == 3) { // Group Sessions
                refreshComboBoxes(gsRoomCB, gsMemberCB, null, "GroupSessionRoom", null);
                refreshGroupSessionTable();
            } else if (idx == 4) { // Gym Bookings
                refreshComboBoxes(geRoomCB, geMemberCB, null, "GymRoom", null);
                refreshGymEventTable();
            } else if (idx == 5) { // Trainer Sessions
                refreshComboBoxes(teRoomCB, teMemberCB, teTrainerCB, "GymRoom", Member.MemberType.VIP);
                refreshTrainerEventTable();
            } else if (idx == 6) { // Workout & Equipment
                refreshComboBoxes(null, wlMemberCB, null, null, null);
                refreshWorkoutTable();
                refreshEquipmentTable();
            }
        });

        refreshAllTables();
        setVisible(true);
    }

    // ==================== MEMBERS TAB ====================

    private JPanel buildMembersPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        memberTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Surname", "Age", "Gender", "Type", "Events", "Workouts"}, 0);
        JTable table = new JTable(memberTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField nameF = new JTextField(10), surnameF = new JTextField(10), ageF = new JTextField(4);
        JComboBox<Gender> genderCB = new JComboBox<>(Gender.values());
        JComboBox<Member.MemberType> typeCB = new JComboBox<>(Member.MemberType.values());
        JButton addBtn = new JButton("Add Member"), removeBtn = new JButton("Remove Selected");

        form.add(new JLabel("Name:")); form.add(nameF);
        form.add(new JLabel("Surname:")); form.add(surnameF);
        form.add(new JLabel("Age:")); form.add(ageF);
        form.add(new JLabel("Gender:")); form.add(genderCB);
        form.add(new JLabel("Type:")); form.add(typeCB);
        form.add(addBtn); form.add(removeBtn);
        panel.add(form, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            try {
                String n = nameF.getText().trim(), s = surnameF.getText().trim();
                if (n.isEmpty() || s.isEmpty()) { showError("Name and surname required"); return; }
                int age = Integer.parseInt(ageF.getText().trim());
                Member m = new Member(n, s, age, (Gender) genderCB.getSelectedItem(), (Member.MemberType) typeCB.getSelectedItem());
                management.addMember(m);
                refreshMemberTable();
                nameF.setText(""); surnameF.setText(""); ageF.setText("");
            } catch (NumberFormatException ex) { showError("Invalid age"); }
        });

        removeBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a member"); return; }
            int id = (int) memberTableModel.getValueAt(row, 0);
            Member m = management.findMember(id);
            if (m != null) { management.removeMember(m); refreshMemberTable(); }
        });

        return panel;
    }

    // ==================== TRAINERS TAB ====================

    private JPanel buildTrainersPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        trainerTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Surname", "Specialization", "Shifts", "Appointments"}, 0);
        JTable table = new JTable(trainerTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        // Add trainer row
        JPanel addRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField nameF = new JTextField(10), surnameF = new JTextField(10), ageF = new JTextField(4), specF = new JTextField(10);
        JComboBox<Gender> genderCB = new JComboBox<>(Gender.values());
        JButton addBtn = new JButton("Add Trainer");
        addRow.add(new JLabel("Name:")); addRow.add(nameF);
        addRow.add(new JLabel("Surname:")); addRow.add(surnameF);
        addRow.add(new JLabel("Age:")); addRow.add(ageF);
        addRow.add(new JLabel("Gender:")); addRow.add(genderCB);
        addRow.add(new JLabel("Spec:")); addRow.add(specF);
        addRow.add(addBtn);
        form.add(addRow);

        // Add shift row
        JPanel shiftRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JComboBox<DayOfWeek> dayCB = new JComboBox<>(DayOfWeek.values());
        JTextField startF = new JTextField(5), endF = new JTextField(5);
        JButton addShiftBtn = new JButton("Add Shift to Selected");
        JButton removeBtn = new JButton("Remove Trainer");
        JButton viewShiftsBtn = new JButton("View All Shifts");
        shiftRow.add(new JLabel("Day:")); shiftRow.add(dayCB);
        shiftRow.add(new JLabel("Start (HH.MM):")); shiftRow.add(startF);
        shiftRow.add(new JLabel("End (HH.MM):")); shiftRow.add(endF);
        shiftRow.add(addShiftBtn); shiftRow.add(removeBtn); shiftRow.add(viewShiftsBtn);
        form.add(shiftRow);

        panel.add(form, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            try {
                String n = nameF.getText().trim(), s = surnameF.getText().trim(), sp = specF.getText().trim();
                if (n.isEmpty() || s.isEmpty() || sp.isEmpty()) { showError("All fields required"); return; }
                int age = Integer.parseInt(ageF.getText().trim());
                PersonalTrainer t = new PersonalTrainer(n, s, age, (Gender) genderCB.getSelectedItem(), sp);
                management.addTrainer(t);
                refreshTrainerTable();
                nameF.setText(""); surnameF.setText(""); ageF.setText(""); specF.setText("");
            } catch (NumberFormatException ex) { showError("Invalid age"); }
        });

        addShiftBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a trainer first"); return; }
            try {
                int id = (int) trainerTableModel.getValueAt(row, 0);
                PersonalTrainer t = management.findTrainer(id);
                if (t == null) return;
                LocalTime start = LocalTime.parse(startF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                LocalTime end = LocalTime.parse(endF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                t.addWorkingShift(new WorkingShift(new LocalTimeInterval(start, end), (DayOfWeek) dayCB.getSelectedItem()));
                refreshTrainerTable();
                startF.setText(""); endF.setText("");
            } catch (DateTimeParseException ex) { showError("Use HH.MM format (e.g. 09.00)");
            } catch (ShiftConflictException ex) { showError(ex.getMessage()); }
        });

        removeBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a trainer"); return; }
            int id = (int) trainerTableModel.getValueAt(row, 0);
            PersonalTrainer t = management.findTrainer(id);
            if (t != null) { management.removeTrainer(t); refreshTrainerTable(); }
        });

        viewShiftsBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a trainer first"); return; }
            int id = (int) trainerTableModel.getValueAt(row, 0);
            PersonalTrainer t = management.findTrainer(id);
            if (t == null) return;
            StringBuilder sb = new StringBuilder();
            sb.append("Shifts for ").append(t.getName()).append(" ").append(t.getSurname()).append(":\n\n");
            if (t.getWeeklySchedule().isEmpty()) {
                sb.append("No shifts assigned.");
            } else {
                for (WorkingShift ws : t.getWeeklySchedule()) {
                    sb.append("  • ").append(ws.toString()).append("\n");
                }
            }
            JOptionPane.showMessageDialog(this, sb.toString(), "All Shifts", JOptionPane.INFORMATION_MESSAGE);
        });

        return panel;
    }

    // ==================== ROOMS TAB ====================

    private JPanel buildRoomsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        roomTableModel = new DefaultTableModel(new String[]{"ID", "Type", "Name", "Capacity", "Events"}, 0);
        JTable table = new JTable(roomTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField nameF = new JTextField(12), capF = new JTextField(5);
        String[] roomTypes = {"Gym Room", "Group Session Room"};
        JComboBox<String> typeCB = new JComboBox<>(roomTypes);
        JButton addBtn = new JButton("Add Room"), removeBtn = new JButton("Remove Selected");
        JLabel capLabel = new JLabel("Capacity (Class only):");

        form.add(new JLabel("Name:")); form.add(nameF);
        form.add(new JLabel("Type:")); form.add(typeCB);
        form.add(capLabel); form.add(capF);
        form.add(addBtn); form.add(removeBtn);
        panel.add(form, BorderLayout.SOUTH);

        // Initially hide capacity field since "Gym Room" is selected by default
        capLabel.setVisible(false);
        capF.setVisible(false);

        typeCB.addItemListener(ev -> {
            boolean isGroupSession = "Group Session Room".equals(typeCB.getSelectedItem());
            capLabel.setVisible(isGroupSession);
            capF.setVisible(isGroupSession);
            form.revalidate();
            form.repaint();
        });

        addBtn.addActionListener(e -> {
            String name = nameF.getText().trim();
            if (name.isEmpty()) { showError("Name required"); return; }
            String type = (String) typeCB.getSelectedItem();
            if ("Gym Room".equals(type)) {
                management.addRoom(new GymRoom(name));
            } else {
                try {
                    int cap = Integer.parseInt(capF.getText().trim());
                    if (cap <= 0) { showError("Capacity must be > 0"); return; }
                    management.addRoom(new GroupSessionRoom(name, cap));
                } catch (NumberFormatException ex) { showError("Invalid capacity"); return; }
            }
            refreshRoomTable();
            nameF.setText(""); capF.setText("");
        });

        removeBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a room"); return; }
            int id = (int) roomTableModel.getValueAt(row, 0);
            Room r = findRoom(id);
            if (r != null) { management.removeRoom(r); refreshRoomTable(); }
        });

        return panel;
    }

    // ==================== GROUP SESSIONS TAB ====================

    private JPanel buildGroupSessionPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        groupSessionTableModel = new DefaultTableModel(new String[]{"Event ID", "Session Type", "Room", "Date", "Time", "Min Level", "Participants"}, 0);
        JTable table = new JTable(groupSessionTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        // Create session row
        JPanel createRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JComboBox<GroupSessionEvent.SessionType> sessionCB = new JComboBox<>(GroupSessionEvent.SessionType.values());
        JTextField dateF = new JTextField(8), startF = new JTextField(5), endF = new JTextField(5);
        JButton createBtn = new JButton("Create Session");

        createRow.add(new JLabel("Type:")); createRow.add(sessionCB);
        createRow.add(new JLabel("Room:"));
        gsRoomCB = new JComboBox<>();
        createRow.add(gsRoomCB);
        createRow.add(new JLabel("Date (DD.MM.YYYY):")); createRow.add(dateF);
        createRow.add(new JLabel("Start:")); createRow.add(startF);
        createRow.add(new JLabel("End:")); createRow.add(endF);
        
        createRow.add(createBtn);
        form.add(createRow);

        // Add participant row
        JPanel joinRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        gsMemberCB = new JComboBox<>();
        JButton joinBtn = new JButton("Add Member to Selected Session");
        JButton cancelBtn = new JButton("Cancel Session");
        JButton showParticipantsBtn = new JButton("Show Participants");
        JButton refreshBtn = new JButton("Refresh");
        joinRow.add(new JLabel("Member:")); joinRow.add(gsMemberCB);
        joinRow.add(joinBtn); joinRow.add(cancelBtn); joinRow.add(showParticipantsBtn); joinRow.add(refreshBtn);
        form.add(joinRow);

        panel.add(form, BorderLayout.SOUTH);

        refreshBtn.addActionListener(e -> {
            refreshGroupSessionTable();
            refreshComboBoxes(gsRoomCB, gsMemberCB, null, "GroupSessionRoom", null);
        });

        createBtn.addActionListener(e -> {
            try {
                Room room = getSelectedRoom(gsRoomCB);
                if (room == null) { showError("Select a room"); return; }
                LocalDate date = LocalDate.parse(dateF.getText().trim(), DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                LocalTime start = LocalTime.parse(startF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                LocalTime end = LocalTime.parse(endF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                GroupSessionEvent evt = new GroupSessionEvent(room, start, end, date, (GroupSessionEvent.SessionType) sessionCB.getSelectedItem());
                management.addGroupSessionEvent(evt);
                refreshGroupSessionTable();
                dateF.setText(""); startF.setText(""); endF.setText("");
            } catch (DateTimeParseException ex) { showError("Invalid date/time format");
            } catch (Event.DuplicateEventException ex) { showError(ex.getMessage());
            } catch (Event.EventTimeConflictsException ex) { showError(ex.getMessage());
            } catch (Event.InvalidRoomTypeException ex) { showError(ex.getMessage()); }
        });

        joinBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a session"); return; }
            Member m = getSelectedMember(gsMemberCB);
            if (m == null) { showError("Select a member"); return; }
            int eventId = (int) groupSessionTableModel.getValueAt(row, 0);
            GroupSessionEvent evt = findGroupSession(eventId);
            if (evt == null) return;
            try {
                evt.addParticipant(m);
                refreshGroupSessionTable();
                refreshMemberTable();
            } catch (Exception ex) { showError(ex.getMessage()); }
        });

        cancelBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a session to cancel"); return; }
            int eventId = (int) groupSessionTableModel.getValueAt(row, 0);
            GroupSessionEvent evt = findGroupSession(eventId);
            if (evt == null) return;
            int confirm = JOptionPane.showConfirmDialog(this, "Cancel this group session?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                management.removeGroupSessionEvent(evt);
                refreshGroupSessionTable();
                refreshMemberTable();
            }
        });

        showParticipantsBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select a session first"); return; }
            int eventId = (int) groupSessionTableModel.getValueAt(row, 0);
            GroupSessionEvent evt = findGroupSession(eventId);
            if (evt == null) return;
            StringBuilder sb = new StringBuilder();
            sb.append("Participants for ").append(evt.getSessionType()).append(" session (ID: ").append(eventId).append("):\n\n");
            if (evt.getParticipants().isEmpty()) {
                sb.append("No participants yet.");
            } else {
                int i = 1;
                for (Member m : evt.getParticipants()) {
                    sb.append("  ").append(i++).append(". ").append(m.getName()).append(" ").append(m.getSurname())
                      .append(" (").append(m.getMembershipType()).append(")\n");
                }
            }
            JOptionPane.showMessageDialog(this, sb.toString(), "Participants", JOptionPane.INFORMATION_MESSAGE);
        });

        // Initial population
        SwingUtilities.invokeLater(() -> refreshComboBoxes(gsRoomCB, gsMemberCB, null, "GroupSessionRoom", null));

        return panel;
    }

    // ==================== GYM BOOKINGS TAB ====================

    private JPanel buildGymEventPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        gymEventTableModel = new DefaultTableModel(new String[]{"Event ID", "Member", "Room", "Date", "Time"}, 0);
        JTable table = new JTable(gymEventTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        geMemberCB = new JComboBox<>();
        geRoomCB = new JComboBox<>();
        JTextField dateF = new JTextField(8), startF = new JTextField(5), endF = new JTextField(5);
        JButton createBtn = new JButton("Book Gym Session"), refreshBtn = new JButton("Refresh");

        form.add(new JLabel("Member:")); form.add(geMemberCB);
        form.add(new JLabel("Gym Room:")); form.add(geRoomCB);
        form.add(new JLabel("Date (DD.MM.YYYY):")); form.add(dateF);
        form.add(new JLabel("Start:")); form.add(startF);
        form.add(new JLabel("End:")); form.add(endF);
        form.add(createBtn); form.add(refreshBtn);
        panel.add(form, BorderLayout.SOUTH);

        refreshBtn.addActionListener(e -> {
            refreshGymEventTable();
            refreshComboBoxes(geRoomCB, geMemberCB, null, "GymRoom", null);
        });

        createBtn.addActionListener(e -> {
            try {
                Member m = getSelectedMember(geMemberCB);
                Room room = getSelectedRoom(geRoomCB);
                if (m == null || room == null) { showError("Select member and room"); return; }
                LocalDate date = LocalDate.parse(dateF.getText().trim(), DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                LocalTime start = LocalTime.parse(startF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                LocalTime end = LocalTime.parse(endF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                GymEvent evt = new GymEvent(room, start, end, date, m);
                management.addGymEvent(evt);
                refreshGymEventTable();
                dateF.setText(""); startF.setText(""); endF.setText("");
            } catch (DateTimeParseException ex) { showError("Invalid date/time format");
            } catch (Exception ex) { showError(ex.getMessage()); }
        });

        SwingUtilities.invokeLater(() -> refreshComboBoxes(geRoomCB, geMemberCB, null, "GymRoom", null));
        return panel;
    }

    // ==================== TRAINER SESSIONS TAB ====================

    private JPanel buildTrainerEventPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        trainerEventTableModel = new DefaultTableModel(new String[]{"Event ID", "VIP Member", "Trainer", "Room", "Date", "Time"}, 0);
        JTable table = new JTable(trainerEventTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        // Row 1: combo boxes
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        teMemberCB = new JComboBox<>();
        teTrainerCB = new JComboBox<>();
        teRoomCB = new JComboBox<>();
        row1.add(new JLabel("VIP Member:")); row1.add(teMemberCB);
        row1.add(new JLabel("Trainer:")); row1.add(teTrainerCB);
        row1.add(new JLabel("Room:")); row1.add(teRoomCB);
        form.add(row1);

        // Row 2: date/time fields + buttons
        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField dateF = new JTextField(8), startF = new JTextField(5), endF = new JTextField(5);
        JButton createBtn = new JButton("Book Trainer Session"), refreshBtn = new JButton("Refresh");
        row2.add(new JLabel("Date (DD.MM.YYYY):")); row2.add(dateF);
        row2.add(new JLabel("Start:")); row2.add(startF);
        row2.add(new JLabel("End:")); row2.add(endF);
        row2.add(createBtn); row2.add(refreshBtn);
        form.add(row2);

        panel.add(form, BorderLayout.SOUTH);

        refreshBtn.addActionListener(e -> {
            refreshTrainerEventTable();
            refreshComboBoxes(teRoomCB, teMemberCB, teTrainerCB, "GymRoom", Member.MemberType.VIP);
        });

        createBtn.addActionListener(e -> {
            try {
                Member m = getSelectedMember(teMemberCB);
                PersonalTrainer t = getSelectedTrainer(teTrainerCB);
                Room room = getSelectedRoom(teRoomCB);
                if (m == null || t == null || room == null) { showError("Select all fields"); return; }
                LocalDate date = LocalDate.parse(dateF.getText().trim(), DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                LocalTime start = LocalTime.parse(startF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                LocalTime end = LocalTime.parse(endF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));
                TrainerEvent evt = new TrainerEvent(room, start, end, date, t, m);
                management.addTrainerEvent(evt);
                refreshTrainerEventTable();
                dateF.setText(""); startF.setText(""); endF.setText("");
            } catch (DateTimeParseException ex) { showError("Invalid date/time format");
            } catch (TrainerEvent.MembershipAccessDeniedException ex) { showError("Only VIP members can book trainer sessions");
            } catch (TrainerEvent.TrainerUnavailableException ex) { showError(ex.getMessage());
            } catch (Exception ex) { showError(ex.getMessage()); }
        });

        SwingUtilities.invokeLater(() -> refreshComboBoxes(teRoomCB, teMemberCB, teTrainerCB, "GymRoom", Member.MemberType.VIP));
        return panel;
    }

    // ==================== WORKOUT LOG TAB ====================

    private JPanel buildWorkoutPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        workoutTableModel = new DefaultTableModel(new String[]{"Member", "Date", "Exercise", "Duration (min)", "Notes"}, 0);
        JTable table = new JTable(workoutTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        wlMemberCB = new JComboBox<>();
        JTextField dateF = new JTextField(8), exerciseF = new JTextField(10), durationF = new JTextField(4), notesF = new JTextField(15);
        JButton logBtn = new JButton("Log Workout"), refreshBtn = new JButton("Refresh");

        form.add(new JLabel("Member:")); form.add(wlMemberCB);
        form.add(new JLabel("Date (DD.MM.YYYY):")); form.add(dateF);
        form.add(new JLabel("Exercise:")); form.add(exerciseF);
        form.add(new JLabel("Duration (min):")); form.add(durationF);
        form.add(new JLabel("Notes:")); form.add(notesF);
        form.add(logBtn); form.add(refreshBtn);
        panel.add(form, BorderLayout.SOUTH);

        refreshBtn.addActionListener(e -> {
            refreshWorkoutTable();
            refreshComboBoxes(null, wlMemberCB, null, null, null);
        });

        logBtn.addActionListener(e -> {
            try {
                Member m = getSelectedMember(wlMemberCB);
                if (m == null) { showError("Select a member"); return; }
                LocalDate date = LocalDate.parse(dateF.getText().trim(), DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                String exercise = exerciseF.getText().trim();
                if (exercise.isEmpty()) { showError("Exercise type required"); return; }
                int duration = Integer.parseInt(durationF.getText().trim());
                String notes = notesF.getText().trim();
                m.logWorkout(new WorkoutLog(date, exercise, duration, notes));
                refreshWorkoutTable();
                refreshMemberTable();
                dateF.setText(""); exerciseF.setText(""); durationF.setText(""); notesF.setText("");
            } catch (DateTimeParseException ex) { showError("Use DD.MM.YYYY format");
            } catch (NumberFormatException ex) { showError("Invalid duration"); }
        });

        SwingUtilities.invokeLater(() -> refreshComboBoxes(null, wlMemberCB, null, null, null));
        return panel;
    }

    // ==================== USED EQUIPMENTS TAB ====================

    private JPanel buildEquipmentPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        equipmentTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Usage Count"}, 0);
        JTable table = new JTable(equipmentTableModel);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField nameF = new JTextField(15);
        JButton addBtn = new JButton("Add Equipment");
        JButton removeBtn = new JButton("Remove Selected");
        JButton useBtn = new JButton("Set Usage (+1)");
        JButton maintainBtn = new JButton("Perform Maintenance");
        JButton refreshBtn = new JButton("Refresh");

        form.add(new JLabel("Name:")); form.add(nameF);
        form.add(addBtn); form.add(removeBtn); form.add(useBtn); form.add(maintainBtn); form.add(refreshBtn);
        panel.add(form, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            String name = nameF.getText().trim();
            if (name.isEmpty()) { showError("Equipment name required"); return; }
            management.addEquipment(new Equipment(name));
            refreshEquipmentTable();
            nameF.setText("");
        });

        removeBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select an equipment"); return; }
            int id = (int) equipmentTableModel.getValueAt(row, 0);
            Equipment eq = management.findEquipment(id);
            if (eq != null) { management.removeEquipment(eq); refreshEquipmentTable(); }
        });

        useBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select an equipment"); return; }
            int id = (int) equipmentTableModel.getValueAt(row, 0);
            Equipment eq = management.findEquipment(id);
            if (eq != null) { eq.incrementUsage(); refreshEquipmentTable(); }
        });

        maintainBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showError("Select an equipment"); return; }
            int id = (int) equipmentTableModel.getValueAt(row, 0);
            Equipment eq = management.findEquipment(id);
            if (eq != null) {
                int confirm = JOptionPane.showConfirmDialog(this, "Perform maintenance on '" + eq.getName() + "'? This will reset usage count to 0.", "Confirm Maintenance", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    eq.performMaintenance();
                    refreshEquipmentTable();
                }
            }
        });

        refreshBtn.addActionListener(e -> refreshEquipmentTable());

        return panel;
    }

    // ==================== REFRESH METHODS ====================

    private void refreshAllTables() {
        refreshMemberTable();
        refreshTrainerTable();
        refreshRoomTable();
        refreshGroupSessionTable();
        refreshGymEventTable();
        refreshTrainerEventTable();
        refreshWorkoutTable();
        refreshEquipmentTable();
    }

    private void refreshMemberTable() {
        memberTableModel.setRowCount(0);
        for (Member m : management.getMembers()) {
            memberTableModel.addRow(new Object[]{m.getId(), m.getName(), m.getSurname(), m.getAge(), m.getGender(), m.getMembershipType(), m.getJoinedEvents().size(), m.getWorkoutHistory().size()});
        }
    }

    private void refreshTrainerTable() {
        trainerTableModel.setRowCount(0);
        for (PersonalTrainer t : management.getTrainers()) {
            StringBuilder shifts = new StringBuilder();
            for (WorkingShift ws : t.getWeeklySchedule()) {
                if (shifts.length() > 0) shifts.append("; ");
                shifts.append(ws.toString());
            }
            trainerTableModel.addRow(new Object[]{t.getId(), t.getName(), t.getSurname(), t.getSpecialization(), shifts.toString(), t.getAppointments().size()});
        }
    }

    private void refreshRoomTable() {
        roomTableModel.setRowCount(0);
        for (Room r : management.getRooms()) {
            String type = (r instanceof GymRoom) ? "Gym" : "Group Session";
            String cap = (r instanceof GymRoom) ? "Unlimited" : String.valueOf(r.getCapacity());
            roomTableModel.addRow(new Object[]{r.getId(), type, r.getName(), cap, r.getScheduledEvents().size()});
        }
    }

    private void refreshGroupSessionTable() {
        groupSessionTableModel.setRowCount(0);
        for (GroupSessionEvent e : management.getGroupSessionEvents()) {
            groupSessionTableModel.addRow(new Object[]{e.getID(), e.getSessionType(), e.getPlace().getName(), e.getDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), e.getTimeInterval().getInfo(), e.getMinimumMembershipLevel(), e.getParticipants().size() + "/" + e.getPlace().getCapacity()});
        }
    }

    private void refreshGymEventTable() {
        gymEventTableModel.setRowCount(0);
        for (GymEvent e : management.getGymEvents()) {
            String memberName = e.getParticipants().isEmpty() ? "N/A" : e.getParticipants().get(0).toString();
            gymEventTableModel.addRow(new Object[]{e.getID(), memberName, e.getPlace().getName(), e.getDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), e.getTimeInterval().getInfo()});
        }
    }

    private void refreshTrainerEventTable() {
        trainerEventTableModel.setRowCount(0);
        for (TrainerEvent e : management.getTrainerEvents()) {
            String memberName = e.getParticipants().isEmpty() ? "N/A" : e.getParticipants().get(0).toString();
            trainerEventTableModel.addRow(new Object[]{e.getID(), memberName, e.getTrainer().toString(), e.getPlace().getName(), e.getDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), e.getTimeInterval().getInfo()});
        }
    }

    private void refreshWorkoutTable() {
        workoutTableModel.setRowCount(0);
        for (Member m : management.getMembers()) {
            for (WorkoutLog log : m.getWorkoutHistory()) {
                workoutTableModel.addRow(new Object[]{m.toString(), log.getDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), log.getExerciseType(), log.getDurationMinutes(), log.getNotes()});
            }
        }
    }

    private void refreshEquipmentTable() {
        if (equipmentTableModel == null) return;
        equipmentTableModel.setRowCount(0);
        for (Equipment eq : management.getEquipments()) {
            equipmentTableModel.addRow(new Object[]{eq.getId(), eq.getName(), eq.getUsageCount()});
        }
    }

    // ==================== HELPER METHODS ====================

    private void refreshComboBoxes(JComboBox<String> roomCB, JComboBox<String> memberCB, JComboBox<String> trainerCB, String roomFilter, Member.MemberType memberFilter) {
        if (roomCB != null) {
            roomCB.removeAllItems();
            for (Room r : management.getRooms()) {
                if (roomFilter == null || 
                   (roomFilter.equals("GymRoom") && r instanceof GymRoom) || 
                   (roomFilter.equals("GroupSessionRoom") && r instanceof GroupSessionRoom)) {
                    roomCB.addItem(r.getId() + ": " + r.toString());
                }
            }
        }
        if (memberCB != null) {
            memberCB.removeAllItems();
            for (Member m : management.getMembers()) {
                if (memberFilter == null || m.getMembershipType() == memberFilter) {
                    memberCB.addItem(m.getId() + ": " + m.toString());
                }
            }
        }
        if (trainerCB != null) {
            trainerCB.removeAllItems();
            for (PersonalTrainer t : management.getTrainers()) {
                trainerCB.addItem(t.getId() + ": " + t.toString());
            }
        }
    }

    private Member getSelectedMember(JComboBox<String> cb) {
        String sel = (String) cb.getSelectedItem();
        if (sel == null) return null;
        int id = Integer.parseInt(sel.split(":")[0].trim());
        return management.findMember(id);
    }

    private PersonalTrainer getSelectedTrainer(JComboBox<String> cb) {
        String sel = (String) cb.getSelectedItem();
        if (sel == null) return null;
        int id = Integer.parseInt(sel.split(":")[0].trim());
        return management.findTrainer(id);
    }

    private Room getSelectedRoom(JComboBox<String> cb) {
        String sel = (String) cb.getSelectedItem();
        if (sel == null) return null;
        int id = Integer.parseInt(sel.split(":")[0].trim());
        return findRoom(id);
    }

    private Room findRoom(int id) {
        for (Room r : management.getRooms()) {
            if (r.getId().equals(id)) return r;
        }
        return null;
    }

    private GroupSessionEvent findGroupSession(int id) {
        for (GroupSessionEvent e : management.getGroupSessionEvents()) {
            if (e.getID().equals(id)) return e;
        }
        return null;
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
