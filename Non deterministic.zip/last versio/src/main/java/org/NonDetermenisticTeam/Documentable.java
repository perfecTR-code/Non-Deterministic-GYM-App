package org.NonDetermenisticTeam;

public interface Documentable {
    public String getInfo();
}
