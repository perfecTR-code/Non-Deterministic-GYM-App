package org.NonDetermenisticTeam.actors;

import org.NonDetermenisticTeam.events.Event;
import java.time.*;
import java.util.ArrayList;

// Abstraction: Room is abstract
public abstract class Room {

    static protected Integer idCounter = 0;
    protected Integer id;
    protected String name;
    protected Integer capacity;
    protected ArrayList<Event> scheduledEvents = new ArrayList<Event>();

    public Room(String name, Integer capacity) {
        this.id = idCounter++;
        this.name = name;
        this.capacity = capacity;
    }

    // Loading constructor — preserves saved ID without incrementing counter
    protected Room(int loadedId, String name, Integer capacity) {
        this.id = loadedId;
        this.name = name;
        this.capacity = capacity;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public ArrayList<Event> getScheduledEvents() {
        return scheduledEvents;
    }

    // Polymorphism: subclasses override this to change scheduling behavior
    public void scheduleEvent(Event event) throws Event.DuplicateEventException, Event.EventTimeConflictsException {
        // Check if event is already scheduled
        if (scheduledEvents.contains(event)) {
            throw new Event.DuplicateEventException();
        }

        // Check if the new event clashes with a scheduled event
        for (Event e : scheduledEvents) {
            if (e.getDate().isEqual(event.getDate())) {
                if (e.getTimeInterval().intersects(event.getTimeInterval())) {
                    throw new Event.EventTimeConflictsException();
                }
            }
        }

        scheduledEvents.add(event);
    }

    public void removeEvent(Event event) {
        scheduledEvents.remove(event);
    }

    // Used by DataPersistence to avoid ID collisions when loading saved data
    public static void setIdCounter(int value) {
        idCounter = value;
    }

    public static int getIdCounter() {
        return idCounter;
    }
}
