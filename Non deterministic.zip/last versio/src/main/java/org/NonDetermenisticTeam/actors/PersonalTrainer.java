package org.NonDetermenisticTeam.actors;

import org.NonDetermenisticTeam.Documentable;
import org.NonDetermenisticTeam.events.Event;
import org.NonDetermenisticTeam.utility.LocalTimeInterval;
import org.NonDetermenisticTeam.utility.WorkingShift;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;

// Inheritance: PersonalTrainer extends Person
// Interfaces: implements Documentable
public class PersonalTrainer extends Person implements Documentable {

    // Encapsulation: private fields with controlled access
    private final ArrayList<WorkingShift> weeklySchedule = new ArrayList<WorkingShift>();
    private final ArrayList<Event> appointments = new ArrayList<Event>();
    private String specialization;

    public PersonalTrainer(String name, String surname, Integer age, Gender gender, String specialization) {
        super(name, surname, age, gender);
        this.specialization = specialization;
    }

    // Loading constructor — preserves saved ID
    public PersonalTrainer(int loadedId, String name, String surname, Integer age, Gender gender, String specialization) {
        super(loadedId, name, surname, age, gender);
        this.specialization = specialization;
    }

    // Custom Exception for shift conflicts
    public static class ShiftConflictException extends Exception {
        public ShiftConflictException(String message) {
            super("ShiftConflictException : " + message);
        }
    }

    // --- Schedule management ---

    public void addWorkingShift(WorkingShift shift) throws ShiftConflictException {
        // Check for overlap with existing shifts on the same day
        for (WorkingShift existing : weeklySchedule) {
            if (existing.getWeekDay() == shift.getWeekDay()) {
                if (existing.getShiftHours().intersects(shift.getShiftHours())) {
                    throw new ShiftConflictException(
                            "New shift " + shift + " conflicts with existing shift " + existing
                            + " for trainer " + name + " " + surname);
                }
            }
        }
        weeklySchedule.add(shift);
    }

    public void removeWorkingShift(WorkingShift shift) {
        weeklySchedule.remove(shift);
    }

    public ArrayList<WorkingShift> getWeeklySchedule() {
        return weeklySchedule;
    }

    /**
     * Checks whether the given time interval falls inside one of the trainer's
     * working shifts for the given day-of-week.
     */
    public boolean isAvailableOnDay(DayOfWeek day, LocalTimeInterval requestedInterval) {
        for (WorkingShift shift : weeklySchedule) {
            if (shift.getWeekDay() == day) {
                // The requested interval must be fully contained within the shift hours
                if (shift.getShiftHours().contains(requestedInterval)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks whether the requested time interval conflicts with any existing
     * appointment on the given date.
     */
    public boolean hasConflict(LocalDate date, LocalTimeInterval requestedInterval) {
        for (Event appointment : appointments) {
            if (appointment.getDate().isEqual(date)) {
                if (appointment.getTimeInterval().intersects(requestedInterval)) {
                    return true;
                }
            }
        }
        return false;
    }

    // --- Appointment management ---

    public void addAppointment(Event event) {
        appointments.add(event);
    }

    public void removeAppointment(Event event) {
        appointments.remove(event);
    }

    public ArrayList<Event> getAppointments() {
        return appointments;
    }

    // --- Getters ---

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    // Method Overriding: Documentable.getInfo()
    @Override
    public String getInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Trainer: ").append(name).append(" ").append(surname);
        sb.append(" | ID: ").append(id);
        sb.append(" | Specialization: ").append(specialization);
        sb.append(" | Shifts: ").append(weeklySchedule.size());
        sb.append(" | Appointments: ").append(appointments.size());
        return sb.toString();
    }

    @Override
    public String toString() {
        return name + " " + surname + " (" + specialization + ")";
    }
}
