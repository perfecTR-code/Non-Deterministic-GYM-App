package org.NonDetermenisticTeam.actors;

import org.NonDetermenisticTeam.Documentable;
import org.NonDetermenisticTeam.events.Event;

// Inheritance: GymRoom extends Room
// Method Overriding: scheduleEvent allows overlapping events (no time-conflict check)
public class GymRoom extends Room implements Documentable {

    // GymRoom has no capacity limit — it is the main gym floor
    public GymRoom(String name) {
        super(name, Integer.MAX_VALUE);
    }

    // Method Overloading: additional constructor with capacity for compatibility
    public GymRoom(String name, Integer capacity) {
        super(name, Integer.MAX_VALUE); // capacity is ignored for GymRoom
    }

    // Loading constructor — preserves saved ID
    public GymRoom(int loadedId, String name) {
        super(loadedId, name, Integer.MAX_VALUE);
    }

    // Method Overriding: GymRoom allows overlapping events (multiple members on the floor)
    @Override
    public void scheduleEvent(Event event) throws Event.DuplicateEventException, Event.EventTimeConflictsException {
        if (scheduledEvents.contains(event)) {
            throw new Event.DuplicateEventException();
        }
        // No time-conflict check — gym floor supports concurrent usage
        scheduledEvents.add(event);
    }

    @Override
    public String getInfo() {
        return "Gym Room: " + name
                + " | ID: " + id
                + " | Capacity: Unlimited"
                + " | Scheduled Events: " + scheduledEvents.size();
    }

    @Override
    public String toString() {
        return name + " (Gym Floor)";
    }
}
