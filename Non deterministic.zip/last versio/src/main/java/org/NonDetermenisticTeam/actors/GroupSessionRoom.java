package org.NonDetermenisticTeam.actors;

import org.NonDetermenisticTeam.Documentable;
import org.NonDetermenisticTeam.events.Event;

// Inheritance: GroupSessionRoom extends Room
// GroupSessionRoom is for all group sessions (Yoga, Spinning, CrossFit, Pilates)
// Unlike GymRoom, GroupSessionRoom has a fixed capacity and does NOT allow overlapping events
public class GroupSessionRoom extends Room implements Documentable {

    public GroupSessionRoom(String name, Integer capacity) {
        super(name, capacity);
    }

    // Loading constructor — preserves saved ID
    public GroupSessionRoom(int loadedId, String name, Integer capacity) {
        super(loadedId, name, capacity);
    }

    // Inherits Room's scheduleEvent which enforces time-conflict checks

    @Override
    public String getInfo() {
        return "Group Session Room: " + name
                + " | ID: " + id
                + " | Capacity: " + capacity
                + " | Scheduled Events: " + scheduledEvents.size();
    }

    @Override
    public String toString() {
        return name + " (Group Session Room, cap: " + capacity + ")";
    }
}
