package org.NonDetermenisticTeam.actors;

// Abstraction: Person is abstract — cannot be instantiated directly
public abstract class Person {

    // Encapsulation: private/protected fields with controlled access
    protected Integer id;
    protected String name;
    protected String surname;
    protected Integer age;

    public enum Gender {
        MALE,
        FEMALE,
    }

    protected Gender gender;

    static private Integer idCounter = 0;

    public Person(String name, String surname, Integer age, Gender gender) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.id = idCounter++;
        this.gender = gender;
    }

    // Loading constructor — sets explicit ID without incrementing counter
    protected Person(int loadedId, String name, String surname, Integer age, Gender gender) {
        this.id = loadedId;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = gender;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Integer getAge() {
        return age;
    }

    public Gender getGender() {
        return gender;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    // Used by DataPersistence to avoid ID collisions when loading saved data
    public static void setIdCounter(int value) {
        idCounter = value;
    }

    public static int getIdCounter() {
        return idCounter;
    }
}
