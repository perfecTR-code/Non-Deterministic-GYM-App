package org.NonDetermenisticTeam.actors;

import org.NonDetermenisticTeam.Documentable;
import org.NonDetermenisticTeam.events.Event;

// Inheritance: ClassRoom extends Room
// ClassRoom is for group sessions (Yoga, Spinning, CrossFit, Pilates)
// Unlike GymRoom, ClassRoom has a fixed capacity and does NOT allow overlapping events
public class ClassRoom extends Room implements Documentable {

    public ClassRoom(String name, Integer capacity) {
        super(name, capacity);
    }

    // Inherits Room's scheduleEvent which enforces time-conflict checks

    @Override
    public String getInfo() {
        return "Class Room: " + name
                + " | ID: " + id
                + " | Capacity: " + capacity
                + " | Scheduled Events: " + scheduledEvents.size();
    }

    @Override
    public String toString() {
        return name + " (Class Room, cap: " + capacity + ")";
    }
}
