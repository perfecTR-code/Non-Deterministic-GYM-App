package org.NonDetermenisticTeam.utility;

import org.NonDetermenisticTeam.Documentable;

// Composition: Equipment objects are managed by Management
public class Equipment implements Documentable {

    private static int idCounter = 0;
    private final int id;
    private final String name;
    private int usageCount;

    public Equipment(String name) {
        this.id = idCounter++;
        this.name = name;
        this.usageCount = 0;
    }

    // Constructor for loading from file (with explicit id and usageCount)
    public Equipment(int id, String name, int usageCount) {
        this.id = id;
        this.name = name;
        this.usageCount = usageCount;
    }

    public void incrementUsage() {
        usageCount++;
    }

    public void performMaintenance() {
        usageCount = 0;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getUsageCount() {
        return usageCount;
    }

    public static void setIdCounter(int value) {
        idCounter = value;
    }

    public static int getIdCounter() {
        return idCounter;
    }

    @Override
    public String getInfo() {
        return "Equipment: " + name
                + " | ID: " + id
                + " | Usage Count: " + usageCount;
    }

    @Override
    public String toString() {
        return name + " (Usage: " + usageCount + ")";
    }
}
