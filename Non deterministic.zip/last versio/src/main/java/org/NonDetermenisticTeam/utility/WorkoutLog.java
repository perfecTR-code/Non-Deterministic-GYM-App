package org.NonDetermenisticTeam.utility;

import org.NonDetermenisticTeam.Documentable;

import java.time.LocalDate;

// Composition: WorkoutLog is composed into Member's workoutHistory list
public class WorkoutLog implements Documentable {

    private final LocalDate date;
    private final String exerciseType;
    private final int durationMinutes;
    private final String notes;

    public WorkoutLog(LocalDate date, String exerciseType, int durationMinutes, String notes) {
        this.date = date;
        this.exerciseType = exerciseType;
        this.durationMinutes = durationMinutes;
        this.notes = notes;
    }

    // Method Overloading: constructor without notes
    public WorkoutLog(LocalDate date, String exerciseType, int durationMinutes) {
        this(date, exerciseType, durationMinutes, "");
    }

    public LocalDate getDate() {
        return date;
    }

    public String getExerciseType() {
        return exerciseType;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public String getNotes() {
        return notes;
    }

    @Override
    public String getInfo() {
        return date + " | " + exerciseType + " | " + durationMinutes + " min"
                + (notes.isEmpty() ? "" : " | " + notes);
    }

    @Override
    public String toString() {
        return getInfo();
    }
}
