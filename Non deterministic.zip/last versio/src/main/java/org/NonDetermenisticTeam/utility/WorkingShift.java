package org.NonDetermenisticTeam.utility;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;

public class WorkingShift {
    LocalTimeInterval shiftHours;
    DayOfWeek weekDay;

    public WorkingShift(LocalTimeInterval shiftHours,DayOfWeek weekDay){
        this.weekDay= weekDay;
        this.shiftHours = shiftHours;
    }

    public LocalTimeInterval getShiftHours() {
        return this.shiftHours;
    }

    public DayOfWeek getWeekDay() {
        return weekDay;
    }

    @Override
    public String toString() {
        return weekDay + " " + shiftHours.getInfo();
    }

}
