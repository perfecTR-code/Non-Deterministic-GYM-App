package org.NonDetermenisticTeam.utility;

import org.NonDetermenisticTeam.Management;
import org.NonDetermenisticTeam.actors.*;
import org.NonDetermenisticTeam.actors.Person.Gender;
import org.NonDetermenisticTeam.events.Event;
import org.NonDetermenisticTeam.events.GroupSessionEvent;
import org.NonDetermenisticTeam.events.GymEvent;
import org.NonDetermenisticTeam.events.TrainerEvent;

import java.io.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Handles reading/writing all application data to/from .txt files.
 * Uses pipe-delimited format. Files are stored in a "data/" directory.
 */
public class DataPersistence {

    private static final String DATA_DIR = "data";
    private static final String MEMBERS_FILE = DATA_DIR + "/members.txt";
    private static final String TRAINERS_FILE = DATA_DIR + "/trainers.txt";
    private static final String ROOMS_FILE = DATA_DIR + "/rooms.txt";
    private static final String WORKOUT_LOGS_FILE = DATA_DIR + "/workout_logs.txt";
    private static final String GROUP_SESSIONS_FILE = DATA_DIR + "/group_sessions.txt";
    private static final String EQUIPMENTS_FILE = DATA_DIR + "/equipments.txt";
    private static final String GYM_EVENTS_FILE = DATA_DIR + "/gym_events.txt";
    private static final String TRAINER_EVENTS_FILE = DATA_DIR + "/trainer_events.txt";

    // --- Save All ---

    public static void saveAll(Management management) {
        ensureDataDir();
        saveMembers(management.getMembers());
        saveTrainers(management.getTrainers());
        saveRooms(management.getRooms());
        saveWorkoutLogs(management.getMembers());
        saveGroupSessions(management.getGroupSessionEvents());
        saveGymEvents(management.getGymEvents());
        saveTrainerEvents(management.getTrainerEvents());
        saveEquipments(management.getEquipments());
    }

    // --- Load All ---

    public static void loadAll(Management management) {
        loadRooms(management);
        loadMembers(management);
        loadTrainers(management);
        loadWorkoutLogs(management);
        loadGroupSessions(management);
        loadGymEvents(management);
        loadTrainerEvents(management);
        loadEquipments(management);
    }

    // --- Members: name|surname|age|gender|memberType ---

    private static void saveMembers(ArrayList<Member> members) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(MEMBERS_FILE))) {
            writer.println(Person.getIdCounter()); // first line = next ID counter
            for (Member m : members) {
                writer.println(m.getId() + "|" + m.getName() + "|" + m.getSurname()
                        + "|" + m.getAge() + "|" + m.getGender() + "|" + m.getMembershipType());
            }
        } catch (IOException e) {
            System.err.println("Error saving members: " + e.getMessage());
        }
    }

    private static void loadMembers(Management management) {
        File file = new File(MEMBERS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String counterLine = reader.readLine();
            if (counterLine != null) {
                Person.setIdCounter(Integer.parseInt(counterLine.trim()));
            }

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                // parts: id|name|surname|age|gender|memberType
                if (parts.length < 6) continue;

                int savedId = Integer.parseInt(parts[0]);
                String name = parts[1];
                String surname = parts[2];
                int age = Integer.parseInt(parts[3]);
                Gender gender = Gender.valueOf(parts[4]);
                Member.MemberType type = Member.MemberType.valueOf(parts[5]);

                Member member = new Member(savedId, name, surname, age, gender, type);
                management.addMember(member);
            }
        } catch (IOException e) {
            System.err.println("Error loading members: " + e.getMessage());
        }
    }

    // --- Trainers: name|surname|age|gender|specialization|shift1;shift2;... ---
    // Each shift: DAY,HH:MM,HH:MM

    private static void saveTrainers(ArrayList<PersonalTrainer> trainers) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(TRAINERS_FILE))) {
            // Person ID counter is already saved by saveMembers; trainers share the same counter
            for (PersonalTrainer t : trainers) {
                StringBuilder shifts = new StringBuilder();
                for (int i = 0; i < t.getWeeklySchedule().size(); i++) {
                    WorkingShift ws = t.getWeeklySchedule().get(i);
                    if (i > 0) shifts.append(";");
                    shifts.append(ws.getWeekDay())
                          .append(",")
                          .append(ws.getShiftHours().getBeginning())
                          .append(",")
                          .append(ws.getShiftHours().getEnding());
                }
                writer.println(t.getId() + "|" + t.getName() + "|" + t.getSurname()
                        + "|" + t.getAge() + "|" + t.getGender() + "|" + t.getSpecialization()
                        + "|" + shifts);
            }
        } catch (IOException e) {
            System.err.println("Error saving trainers: " + e.getMessage());
        }
    }

    private static void loadTrainers(Management management) {
        File file = new File(TRAINERS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                // parts: id|name|surname|age|gender|specialization|shifts
                if (parts.length < 6) continue;

                int savedId = Integer.parseInt(parts[0]);
                String name = parts[1];
                String surname = parts[2];
                int age = Integer.parseInt(parts[3]);
                Gender gender = Gender.valueOf(parts[4]);
                String specialization = parts[5];

                PersonalTrainer trainer = new PersonalTrainer(savedId, name, surname, age, gender, specialization);

                // Parse shifts if present
                if (parts.length >= 7 && !parts[6].isEmpty()) {
                    String[] shiftParts = parts[6].split(";");
                    for (String sp : shiftParts) {
                        String[] shiftFields = sp.split(",");
                        if (shiftFields.length == 3) {
                            DayOfWeek day = DayOfWeek.valueOf(shiftFields[0]);
                            LocalTime start = LocalTime.parse(shiftFields[1]);
                            LocalTime end = LocalTime.parse(shiftFields[2]);
                            LocalTimeInterval interval = new LocalTimeInterval(start, end);
                            try {
                                trainer.addWorkingShift(new WorkingShift(interval, day));
                            } catch (PersonalTrainer.ShiftConflictException ex) {
                                System.err.println("Warning: Shift conflict while loading trainer data: " + ex.getMessage());
                            }
                        }
                    }
                }

                management.addTrainer(trainer);
            }
        } catch (IOException e) {
            System.err.println("Error loading trainers: " + e.getMessage());
        }
    }

    // --- Rooms: type|name|capacity ---
    // type: GYM or GROUP_SESSION

    private static void saveRooms(ArrayList<Room> rooms) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ROOMS_FILE))) {
            writer.println(Room.getIdCounter());
            for (Room r : rooms) {
                String type = (r instanceof GymRoom) ? "GYM" : "GROUP_SESSION";
                int cap = (r instanceof GymRoom) ? 0 : r.getCapacity();
                writer.println(r.getId() + "|" + type + "|" + r.getName() + "|" + cap);
            }
        } catch (IOException e) {
            System.err.println("Error saving rooms: " + e.getMessage());
        }
    }

    private static void loadRooms(Management management) {
        File file = new File(ROOMS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String counterLine = reader.readLine();
            if (counterLine != null) {
                Room.setIdCounter(Integer.parseInt(counterLine.trim()));
            }

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                // parts: id|type|name|capacity
                if (parts.length < 4) continue;

                int savedId = Integer.parseInt(parts[0]);
                String type = parts[1];
                String name = parts[2];
                int capacity = Integer.parseInt(parts[3]);

                Room room;
                if ("GYM".equals(type)) {
                    room = new GymRoom(savedId, name);
                } else {
                    room = new GroupSessionRoom(savedId, name, capacity);
                }
                management.addRoom(room);
            }
        } catch (IOException e) {
            System.err.println("Error loading rooms: " + e.getMessage());
        }
    }

    // --- Workout Logs: memberID|date|exerciseType|duration|notes ---

    private static void saveWorkoutLogs(ArrayList<Member> members) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(WORKOUT_LOGS_FILE))) {
            for (Member m : members) {
                for (WorkoutLog log : m.getWorkoutHistory()) {
                    writer.println(m.getId() + "|" + log.getDate() + "|" + log.getExerciseType()
                            + "|" + log.getDurationMinutes() + "|" + log.getNotes());
                }
            }
        } catch (IOException e) {
            System.err.println("Error saving workout logs: " + e.getMessage());
        }
    }

    private static void loadWorkoutLogs(Management management) {
        File file = new File(WORKOUT_LOGS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                // parts: memberID|date|exerciseType|duration|notes
                if (parts.length < 4) continue;

                int memberId = Integer.parseInt(parts[0]);
                LocalDate date = LocalDate.parse(parts[1]);
                String exerciseType = parts[2];
                int duration = Integer.parseInt(parts[3]);
                String notes = (parts.length >= 5) ? parts[4] : "";

                Member member = management.findMember(memberId);
                if (member != null) {
                    member.logWorkout(new WorkoutLog(date, exerciseType, duration, notes));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading workout logs: " + e.getMessage());
        }
    }

    // --- Group Sessions: eventId|roomId|sessionType|date|startTime|endTime|participantIds ---
    // participantIds: semicolon-separated list of member IDs

    private static void saveGroupSessions(ArrayList<GroupSessionEvent> sessions) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(GROUP_SESSIONS_FILE))) {
            writer.println(Event.getIdCounter()); // first line = event ID counter
            for (GroupSessionEvent evt : sessions) {
                StringBuilder participantIds = new StringBuilder();
                for (int i = 0; i < evt.getParticipants().size(); i++) {
                    if (i > 0) participantIds.append(";");
                    participantIds.append(evt.getParticipants().get(i).getId());
                }
                writer.println(evt.getID() + "|" + evt.getPlace().getId() + "|" + evt.getSessionType()
                        + "|" + evt.getDate() + "|" + evt.getTimeInterval().getBeginning()
                        + "|" + evt.getTimeInterval().getEnding() + "|" + participantIds);
            }
        } catch (IOException e) {
            System.err.println("Error saving group sessions: " + e.getMessage());
        }
    }

    private static void loadGroupSessions(Management management) {
        File file = new File(GROUP_SESSIONS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String counterLine = reader.readLine();
            if (counterLine != null) {
                Event.setIdCounter(Integer.parseInt(counterLine.trim()));
            }

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                // parts: eventId|roomId|sessionType|date|startTime|endTime|participantIds
                if (parts.length < 6) continue;

                int eventId = Integer.parseInt(parts[0]);
                int roomId = Integer.parseInt(parts[1]);
                GroupSessionEvent.SessionType sessionType = GroupSessionEvent.SessionType.valueOf(parts[2]);
                LocalDate date = LocalDate.parse(parts[3]);
                LocalTime startTime = LocalTime.parse(parts[4]);
                LocalTime endTime = LocalTime.parse(parts[5]);

                // Find the room
                Room room = null;
                for (Room r : management.getRooms()) {
                    if (r.getId().equals(roomId)) {
                        room = r;
                        break;
                    }
                }
                if (room == null) {
                    System.err.println("Warning: Room ID " + roomId + " not found for group session " + eventId);
                    continue;
                }

                // Use the loading constructor (bypasses validation)
                GroupSessionEvent evt = new GroupSessionEvent(eventId, room, startTime, endTime, date, sessionType);

                // Manually schedule the event in the room
                try {
                    room.scheduleEvent(evt);
                } catch (Exception ex) {
                    System.err.println("Warning: Could not schedule loaded group session: " + ex.getMessage());
                }

                // Add participants
                if (parts.length >= 7 && !parts[6].isEmpty()) {
                    String[] participantIds = parts[6].split(";");
                    for (String pid : participantIds) {
                        int memberId = Integer.parseInt(pid.trim());
                        Member member = management.findMember(memberId);
                        if (member != null) {
                            evt.getParticipants().add(member);
                            member.getJoinedEvents().add(evt);
                        }
                    }
                }

                management.addGroupSessionEvent(evt);
            }
        } catch (IOException e) {
            System.err.println("Error loading group sessions: " + e.getMessage());
        }
    }

    // --- Equipments: id|name|usageCount ---

    private static void saveEquipments(ArrayList<Equipment> equipments) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(EQUIPMENTS_FILE))) {
            writer.println(Equipment.getIdCounter()); // first line = equipment ID counter
            for (Equipment eq : equipments) {
                writer.println(eq.getId() + "|" + eq.getName() + "|" + eq.getUsageCount());
            }
        } catch (IOException e) {
            System.err.println("Error saving equipments: " + e.getMessage());
        }
    }

    private static void loadEquipments(Management management) {
        File file = new File(EQUIPMENTS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String counterLine = reader.readLine();
            if (counterLine != null) {
                Equipment.setIdCounter(Integer.parseInt(counterLine.trim()));
            }

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                // parts: id|name|usageCount
                if (parts.length < 3) continue;

                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                int usageCount = Integer.parseInt(parts[2]);

                Equipment equipment = new Equipment(id, name, usageCount);
                management.addEquipment(equipment);
            }
        } catch (IOException e) {
            System.err.println("Error loading equipments: " + e.getMessage());
        }
    }

    // --- Gym Events: eventId|roomId|memberId|date|startTime|endTime ---

    private static void saveGymEvents(java.util.ArrayList<GymEvent> events) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(GYM_EVENTS_FILE))) {
            for (GymEvent evt : events) {
                int memberId = evt.getParticipants().isEmpty() ? -1 : evt.getParticipants().get(0).getId();
                writer.println(evt.getID() + "|" + evt.getPlace().getId() + "|" + memberId
                        + "|" + evt.getDate() + "|" + evt.getTimeInterval().getBeginning()
                        + "|" + evt.getTimeInterval().getEnding());
            }
        } catch (IOException e) {
            System.err.println("Error saving gym events: " + e.getMessage());
        }
    }

    private static void loadGymEvents(Management management) {
        File file = new File(GYM_EVENTS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                if (parts.length < 6) continue;

                int eventId = Integer.parseInt(parts[0]);
                int roomId = Integer.parseInt(parts[1]);
                int memberId = Integer.parseInt(parts[2]);
                LocalDate date = LocalDate.parse(parts[3]);
                LocalTime startTime = LocalTime.parse(parts[4]);
                LocalTime endTime = LocalTime.parse(parts[5]);

                Room room = null;
                for (Room r : management.getRooms()) {
                    if (r.getId().equals(roomId)) { room = r; break; }
                }
                if (room == null) continue;

                GymEvent evt = new GymEvent(eventId, room, startTime, endTime, date);
                try { room.scheduleEvent(evt); } catch (Exception ex) {
                    System.err.println("Warning: Could not schedule loaded gym event: " + ex.getMessage());
                }

                if (memberId >= 0) {
                    Member member = management.findMember(memberId);
                    if (member != null) {
                        evt.getParticipants().add(member);
                        member.getJoinedEvents().add(evt);
                    }
                }

                // Update event ID counter
                if (eventId >= Event.getIdCounter()) {
                    Event.setIdCounter(eventId + 1);
                }

                management.addGymEvent(evt);
            }
        } catch (IOException e) {
            System.err.println("Error loading gym events: " + e.getMessage());
        }
    }

    // --- Trainer Events: eventId|roomId|trainerId|memberId|date|startTime|endTime ---

    private static void saveTrainerEvents(java.util.ArrayList<TrainerEvent> events) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(TRAINER_EVENTS_FILE))) {
            for (TrainerEvent evt : events) {
                int memberId = evt.getParticipants().isEmpty() ? -1 : evt.getParticipants().get(0).getId();
                writer.println(evt.getID() + "|" + evt.getPlace().getId() + "|" + evt.getTrainer().getId()
                        + "|" + memberId + "|" + evt.getDate()
                        + "|" + evt.getTimeInterval().getBeginning()
                        + "|" + evt.getTimeInterval().getEnding());
            }
        } catch (IOException e) {
            System.err.println("Error saving trainer events: " + e.getMessage());
        }
    }

    private static void loadTrainerEvents(Management management) {
        File file = new File(TRAINER_EVENTS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\|");
                if (parts.length < 7) continue;

                int eventId = Integer.parseInt(parts[0]);
                int roomId = Integer.parseInt(parts[1]);
                int trainerId = Integer.parseInt(parts[2]);
                int memberId = Integer.parseInt(parts[3]);
                LocalDate date = LocalDate.parse(parts[4]);
                LocalTime startTime = LocalTime.parse(parts[5]);
                LocalTime endTime = LocalTime.parse(parts[6]);

                Room room = null;
                for (Room r : management.getRooms()) {
                    if (r.getId().equals(roomId)) { room = r; break; }
                }
                if (room == null) continue;

                PersonalTrainer trainer = management.findTrainer(trainerId);
                if (trainer == null) continue;

                TrainerEvent evt = new TrainerEvent(eventId, room, startTime, endTime, date, trainer);
                try { room.scheduleEvent(evt); } catch (Exception ex) {
                    System.err.println("Warning: Could not schedule loaded trainer event: " + ex.getMessage());
                }
                trainer.addAppointment(evt);

                if (memberId >= 0) {
                    Member member = management.findMember(memberId);
                    if (member != null) {
                        evt.getParticipants().add(member);
                        member.getJoinedEvents().add(evt);
                    }
                }

                // Update event ID counter
                if (eventId >= Event.getIdCounter()) {
                    Event.setIdCounter(eventId + 1);
                }

                management.addTrainerEvent(evt);
            }
        } catch (IOException e) {
            System.err.println("Error loading trainer events: " + e.getMessage());
        }
    }

    // --- Utility ---

    private static void ensureDataDir() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
}
