package org.NonDetermenisticTeam.utility;

import org.NonDetermenisticTeam.Documentable;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class LocalTimeInterval implements Documentable {
    private LocalTime begining;
    private LocalTime ending;

    public LocalTimeInterval(LocalTime A,LocalTime B) {
        if(A.isBefore(B)) {
            this.begining = A;
            this.ending = B;
        }
        else{
            this.begining = B;
            this.ending = A;
        }
    }

    public boolean contains(LocalTime A) {
        return !A.isBefore(this.begining) && !A.isAfter(this.ending);
    }

    // Method Overloading: contains(LocalTime) vs contains(LocalTimeInterval)
    public boolean contains(LocalTimeInterval interval){
        LocalTime begin = interval.begining, end = interval.ending;
        return !begin.isBefore(this.begining) && !end.isAfter(this.ending);
    }

    public LocalTime getBeginning() {
        return this.begining;
    }

    public LocalTime getEnding() {
        return this.ending;
    }

    public boolean intersects(LocalTimeInterval interval) {
        return this.contains(interval.begining) || this.contains(interval.ending) || interval.contains(this);
    }

    public String getInfo() {
        return formatTime(this.begining) + " - " + formatTime(this.ending);
    }

    /**
     * Formats a LocalTime as HH.MM (dot separator).
     */
    private String formatTime(LocalTime time) {
        return String.format("%02d.%02d", time.getHour(), time.getMinute());
    }
}
