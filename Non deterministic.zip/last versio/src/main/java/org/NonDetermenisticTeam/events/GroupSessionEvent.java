package org.NonDetermenisticTeam.events;

import org.NonDetermenisticTeam.actors.GroupSessionRoom;
import org.NonDetermenisticTeam.actors.Member;
import org.NonDetermenisticTeam.actors.Room;

import java.time.LocalDate;
import java.time.LocalTime;

// Inheritance: GroupSessionEvent extends Event
// Group classes are only for Premium and VIP members
// Group classes can only take place in Group Session Rooms
public final class GroupSessionEvent extends Event {

    public enum SessionType {
        YOGA,
        SPINNING,
        CROSSFIT,
        PILATES
    }

    private final SessionType sessionType;

    public GroupSessionEvent(Room place, LocalTime starting_time, LocalTime ending_time, LocalDate date, SessionType type) throws EventTimeConflictsException, DuplicateEventException, InvalidRoomTypeException {
        super(place, starting_time, ending_time, date);

        // Validate: group sessions can only take place in Group Session Rooms
        if (!(place instanceof GroupSessionRoom)) {
            throw new InvalidRoomTypeException("Group sessions can only take place in Group Session Rooms");
        }

        // Fixed membership level: Premium and VIP can join
        this.minimumMembershipLevel = Member.MemberType.PREMIUM;
        this.sessionType = type;
    }

    // Loading constructor — skips validation, used by DataPersistence
    public GroupSessionEvent(int loadedId, Room place, LocalTime starting_time, LocalTime ending_time, LocalDate date, SessionType type) {
        super(loadedId, place, starting_time, ending_time, date);
        this.minimumMembershipLevel = Member.MemberType.PREMIUM;
        this.sessionType = type;
    }

    public SessionType getSessionType() {
        return this.sessionType;
    }

}
