package org.NonDetermenisticTeam.events;

import org.NonDetermenisticTeam.actors.GymRoom;
import org.NonDetermenisticTeam.actors.Member;
import org.NonDetermenisticTeam.actors.PersonalTrainer;
import org.NonDetermenisticTeam.actors.Room;
import org.NonDetermenisticTeam.utility.LocalTimeInterval;

import java.time.LocalDate;
import java.time.LocalTime;

// Inheritance: TrainerEvent extends Event
// Trainer events are only for VIP members
// A trainer event consists of exactly one VIP member and one trainer
// Both must be selected at creation time
// Trainer events must be located only in Gym Rooms
public final class TrainerEvent extends Event {

    // Custom Exceptions (Exception Handling with Custom Exceptions)
    public static class TrainerUnavailableException extends Exception {
        public TrainerUnavailableException(String reason) {
            super("TrainerUnavailableException : " + reason);
        }
    }

    public static class MembershipAccessDeniedException extends Exception {
        public MembershipAccessDeniedException() {
            super("MembershipAccessDeniedException : Only VIP members can book personal training sessions");
        }
    }

    // Composition: TrainerEvent "has-a" PersonalTrainer
    private final PersonalTrainer trainer;

    /**
     * Creates a new personal training session.
     *
     * Validations performed:
     * 1. The room must be a Gym Room
     * 2. The booking member must be VIP
     * 3. The requested time must fall within one of the trainer's working shifts
     * 4. The trainer must not have a conflicting appointment at that time
     *
     * @param place                  the gym room where the session takes place
     * @param starting_time          session start time
     * @param ending_time            session end time
     * @param date                   session date
     * @param trainer                the personal trainer for this session
     * @param bookingMember          the VIP member booking the session
     */
    public TrainerEvent(Room place, LocalTime starting_time, LocalTime ending_time,
                        LocalDate date, PersonalTrainer trainer, Member bookingMember)
            throws EventTimeConflictsException, DuplicateEventException,
                   TrainerUnavailableException, MembershipAccessDeniedException,
                   Member.InvalidMembershipType, EventCapacityFullException, InvalidRoomTypeException {

        super(place, starting_time, ending_time, date);

        // Validate: trainer events can only take place in Gym Rooms
        if (!(place instanceof GymRoom)) {
            throw new InvalidRoomTypeException("Trainer events can only take place in Gym Rooms");
        }

        // TrainerEvents are VIP-only: the minimum membership level is always VIP
        this.minimumMembershipLevel = Member.MemberType.VIP;
        this.trainer = trainer;

        // Validate: only VIP members can create/join TrainerEvents
        if (bookingMember.getMembershipType() != Member.MemberType.VIP) {
            throw new MembershipAccessDeniedException();
        }

        // Build the time interval for validation
        LocalTimeInterval requestedInterval = this.getTimeInterval();

        // Validate: requested time must fall inside a trainer's working shift for that day
        if (!trainer.isAvailableOnDay(date.getDayOfWeek(), requestedInterval)) {
            throw new TrainerUnavailableException(
                    "Trainer " + trainer.getName() + " " + trainer.getSurname()
                    + " does not have a working shift covering " + requestedInterval.getInfo()
                    + " on " + date.getDayOfWeek());
        }

        // Validate: trainer must not have a conflicting appointment
        if (trainer.hasConflict(date, requestedInterval)) {
            throw new TrainerUnavailableException(
                    "Trainer " + trainer.getName() + " " + trainer.getSurname()
                    + " already has an appointment that conflicts with "
                    + requestedInterval.getInfo() + " on " + date);
        }

        // All checks passed — register the appointment with the trainer
        trainer.addAppointment(this);

        // Add the booking member as the sole participant
        this.addParticipant(bookingMember);
    }

    // Method Overriding: TrainerEvent allows exactly one VIP participant (set at creation)
    @Override
    public void addParticipant(Member participant)
            throws EventTimeConflictsException, DuplicateEventException,
                   Member.InvalidMembershipType, EventCapacityFullException {

        // A trainer event consists of exactly one member
        if (!participants.isEmpty()) {
            throw new EventCapacityFullException();
        }

        // Enforce VIP-only access
        if (participant.getMembershipType() != Member.MemberType.VIP) {
            throw new Member.InvalidMembershipType();
        }

        // Delegate to parent for duplicate and time-conflict checks
        super.addParticipant(participant);
    }

    @Override
    public void removeParticipant(Member participant) {
        super.removeParticipant(participant);

        // If no participants remain, free the trainer's slot
        if (participants.isEmpty()) {
            trainer.removeAppointment(this);
        }
    }

    // Loading constructor — bypasses all validation, used by DataPersistence
    public TrainerEvent(int loadedId, Room place, LocalTime starting_time, LocalTime ending_time,
                        LocalDate date, PersonalTrainer trainer) {
        super(loadedId, place, starting_time, ending_time, date);
        this.minimumMembershipLevel = Member.MemberType.VIP;
        this.trainer = trainer;
    }

    public PersonalTrainer getTrainer() {
        return trainer;
    }
}
