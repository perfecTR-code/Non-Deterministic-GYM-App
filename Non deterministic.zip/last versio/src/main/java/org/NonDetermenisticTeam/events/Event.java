package org.NonDetermenisticTeam.events;

import org.NonDetermenisticTeam.actors.Member;
import org.NonDetermenisticTeam.actors.Room;
import org.NonDetermenisticTeam.utility.LocalTimeInterval;

import java.util.ArrayList;
import java.time.*;

abstract public class Event {

    protected Room place = null;
    protected ArrayList<Member> participants = new ArrayList<Member>();
    protected Member.MemberType minimumMembershipLevel = null;
    protected Integer id;

    protected LocalTimeInterval timeInterval;
    protected LocalDate date;

    protected static Integer idCounter = 0;

    public static class EventTimeConflictsException extends Exception {
        public EventTimeConflictsException() {
            super("EventTimeConflictsException : Event conflicts with another event");
        }
    }

    public static class DuplicateEventException extends Exception {
        public DuplicateEventException() {
            super("DuplicateEventException : Event already exists in the array");
        }
    }

    public static class EventCapacityFullException extends Exception {
        public EventCapacityFullException() {
            super("EventCapacityFullException : Event is full");
        }
    }

    public static class InvalidRoomTypeException extends Exception {
        public InvalidRoomTypeException(String message) {
            super("InvalidRoomTypeException : " + message);
        }
    }

    public Event(Room place, LocalTime starting_time, LocalTime ending_time, LocalDate date) throws EventTimeConflictsException, DuplicateEventException, InvalidRoomTypeException {
        this.id = idCounter++;
        this.place = place;
        this.timeInterval = new LocalTimeInterval(starting_time, ending_time);
        this.date = date;
        place.scheduleEvent(this);
    }

    // Protected constructor for loading from file — skips scheduleEvent and uses explicit ID
    protected Event(int loadedId, Room place, LocalTime starting_time, LocalTime ending_time, LocalDate date) {
        this.id = loadedId;
        this.place = place;
        this.timeInterval = new LocalTimeInterval(starting_time, ending_time);
        this.date = date;
        // Do NOT call place.scheduleEvent(this) — caller must do it manually after loading
    }

    public void addParticipant(Member participant) throws EventTimeConflictsException, DuplicateEventException, Member.InvalidMembershipType, EventCapacityFullException {
        if (this.participants.size() + 1 > this.place.getCapacity()) {
            throw new EventCapacityFullException();
        }
        participant.joinEvent(this);
        participants.add(participant);
    }

    public void removeParticipant(Member participant) {
        participant.leaveEvent(this);
        participants.remove(participant);
    }

    public Room getPlace() {
        return place;
    }

    public Integer getID() {
        return id;
    }

    public ArrayList<Member> getParticipants() {
        return participants;
    }

    public Member.MemberType getMinimumMembershipLevel() {
        return minimumMembershipLevel;
    }

    public LocalTimeInterval getTimeInterval() {
        return this.timeInterval;
    }

    public LocalDate getDate() {
        return this.date;
    }

    // Used by DataPersistence to avoid ID collisions when loading saved data
    public static void setIdCounter(int value) {
        idCounter = value;
    }

    public static int getIdCounter() {
        return idCounter;
    }
}
