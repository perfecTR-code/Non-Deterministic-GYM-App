package org.NonDetermenisticTeam.events;

import org.NonDetermenisticTeam.actors.GymRoom;
import org.NonDetermenisticTeam.actors.Room;
import org.NonDetermenisticTeam.actors.Member;

import java.time.LocalDate;
import java.time.LocalTime;

// Inheritance: GymEvent extends Event
// Gym events are for everyone (Basic, Premium, VIP)
// Gym events must be located only in Gym Rooms
public final class GymEvent extends Event {

    public GymEvent(Room place, LocalTime starting_time, LocalTime ending_time, LocalDate date, Member member) throws EventTimeConflictsException, DuplicateEventException, Member.InvalidMembershipType, EventCapacityFullException, InvalidRoomTypeException {
        super(place, starting_time, ending_time, date);

        // Validate: gym events can only take place in Gym Rooms
        if (!(place instanceof GymRoom)) {
            throw new InvalidRoomTypeException("Gym events can only take place in Gym Rooms");
        }

        // Fixed membership level: everyone can join
        this.minimumMembershipLevel = Member.MemberType.BASIC;
        this.addParticipant(member);
    }

    // Loading constructor — bypasses validation, used by DataPersistence
    public GymEvent(int loadedId, Room place, LocalTime starting_time, LocalTime ending_time, LocalDate date) {
        super(loadedId, place, starting_time, ending_time, date);
        this.minimumMembershipLevel = Member.MemberType.BASIC;
    }

    @Override public void addParticipant(Member member) throws EventCapacityFullException, DuplicateEventException, Member.InvalidMembershipType, EventTimeConflictsException {
        if(!participants.isEmpty()) {
            throw new EventCapacityFullException();
        }
        member.joinEvent(this);
        participants.add(member);
    }

}
