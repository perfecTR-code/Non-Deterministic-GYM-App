package org.NonDetermenisticTeam;

import org.NonDetermenisticTeam.actors.Member;
import org.NonDetermenisticTeam.actors.PersonalTrainer;
import org.NonDetermenisticTeam.actors.Room;
import org.NonDetermenisticTeam.events.Event;
import org.NonDetermenisticTeam.events.GroupSessionEvent;
import org.NonDetermenisticTeam.events.GymEvent;
import org.NonDetermenisticTeam.events.TrainerEvent;
import org.NonDetermenisticTeam.utility.Equipment;

import java.util.*;

public class Management {

    // Composition: Management "has" collections of domain objects
    private ArrayList<Member> members = new ArrayList<Member>();
    private ArrayList<PersonalTrainer> trainers = new ArrayList<PersonalTrainer>();
    private ArrayList<Room> rooms = new ArrayList<Room>();
    private ArrayList<GymEvent> gymEvents = new ArrayList<GymEvent>();
    private ArrayList<GroupSessionEvent> groupSessionEvents = new ArrayList<GroupSessionEvent>();
    private ArrayList<TrainerEvent> trainerEvents = new ArrayList<TrainerEvent>();
    private ArrayList<Equipment> equipments = new ArrayList<Equipment>();

    public Management() {

    }

    // --- Member management ---

    public void addMember(Member member) {
        members.add(member);
    }

    public void removeMember(Member member) {
        members.remove(member);
    }

    public ArrayList<Member> getMembers() {
        return members;
    }

    // Method Overloading: findMember by ID vs by name
    public Member findMember(Integer id) {
        for (Member m : members) {
            if (m.getId().equals(id)) return m;
        }
        return null;
    }

    public Member findMember(String name, String surname) {
        for (Member m : members) {
            if (m.getName().equals(name) && m.getSurname().equals(surname)) return m;
        }
        return null;
    }

    // --- Trainer management ---

    public void addTrainer(PersonalTrainer trainer) {
        trainers.add(trainer);
    }

    public void removeTrainer(PersonalTrainer trainer) {
        trainers.remove(trainer);
    }

    public ArrayList<PersonalTrainer> getTrainers() {
        return trainers;
    }

    public PersonalTrainer findTrainer(Integer id) {
        for (PersonalTrainer t : trainers) {
            if (t.getId().equals(id)) return t;
        }
        return null;
    }

    // --- Room management ---

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public void removeRoom(Room room) {
        rooms.remove(room);
    }

    public ArrayList<Room> getRooms() {
        return rooms;
    }

    // --- Event management ---

    public void addGymEvent(GymEvent event) {
        gymEvents.add(event);
    }

    public void addGroupSessionEvent(GroupSessionEvent event) {
        groupSessionEvents.add(event);
    }

    public void addTrainerEvent(TrainerEvent event) {
        trainerEvents.add(event);
    }

    public void removeGroupSessionEvent(GroupSessionEvent event) {
        // Remove all participants from the event
        for (Member m : new ArrayList<>(event.getParticipants())) {
            event.removeParticipant(m);
        }
        // Remove event from room's schedule
        event.getPlace().removeEvent(event);
        // Remove from management list
        groupSessionEvents.remove(event);
    }

    public void removeGymEvent(GymEvent event) {
        // Remove all participants from the event
        for (Member m : new ArrayList<>(event.getParticipants())) {
            event.removeParticipant(m);
        }
        // Remove event from room's schedule
        event.getPlace().removeEvent(event);
        // Remove from management list
        gymEvents.remove(event);
    }

    public void removeTrainerEvent(TrainerEvent event) {
        // Remove all participants from the event
        for (Member m : new ArrayList<>(event.getParticipants())) {
            event.removeParticipant(m);
        }
        // Remove trainer's appointment
        event.getTrainer().removeAppointment(event);
        // Remove event from room's schedule
        event.getPlace().removeEvent(event);
        // Remove from management list
        trainerEvents.remove(event);
    }

    public ArrayList<GymEvent> getGymEvents() {
        return gymEvents;
    }

    public ArrayList<GroupSessionEvent> getGroupSessionEvents() {
        return groupSessionEvents;
    }

    public ArrayList<TrainerEvent> getTrainerEvents() {
        return trainerEvents;
    }

    // --- Equipment management ---

    public void addEquipment(Equipment equipment) {
        equipments.add(equipment);
    }

    public void removeEquipment(Equipment equipment) {
        equipments.remove(equipment);
    }

    public ArrayList<Equipment> getEquipments() {
        return equipments;
    }

    public Equipment findEquipment(int id) {
        for (Equipment eq : equipments) {
            if (eq.getId() == id) return eq;
        }
        return null;
    }
}
