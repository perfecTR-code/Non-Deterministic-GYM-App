package org.NonDetermenisticTeam;

import org.NonDetermenisticTeam.utility.DataPersistence;

import javax.swing.*;

public class NonDetermenisticGym {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Management management = new Management();
            DataPersistence.loadAll(management);
            new GymUI(management);
        });
    }
}
