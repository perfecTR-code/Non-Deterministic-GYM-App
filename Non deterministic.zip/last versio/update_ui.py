import re

with open(r"c:\Users\ehank\Desktop\NonDetermenisticGym\src\main\java\org\NonDetermenisticTeam\GymUI.java", "r") as f:
    content = f.read()

# 1. Imports
content = content.replace("import java.time.format.DateTimeParseException;", "import java.time.format.DateTimeParseException;\nimport java.time.format.DateTimeFormatter;")

# 2. Rooms Panel
content = content.replace('"Gym Room", "Class Room"', '"Gym Room", "Group Session Room"')
content = content.replace('management.addRoom(new ClassRoom(name, cap));', 'management.addRoom(new GroupSessionRoom(name, cap));')
content = content.replace('type = (r instanceof GymRoom) ? "Gym" : "Class";', 'type = (r instanceof GymRoom) ? "Gym" : "Group Session";')
content = content.replace('String cap = (r instanceof GymRoom) ? "Unlimited" : String.valueOf(r.getCapacity());', 'String cap = (r instanceof GymRoom) ? "Unlimited" : String.valueOf(r.getCapacity());')

# 3. Trainers Panel
content = content.replace('Start (HH:MM):', 'Start (HH.MM):')
content = content.replace('End (HH:MM):', 'End (HH.MM):')
content = content.replace('Use HH:MM format (e.g. 09:00)', 'Use HH.MM format (e.g. 09.00)')
content = content.replace('LocalTime start = LocalTime.parse(startF.getText().trim());', 'LocalTime start = LocalTime.parse(startF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));')
content = content.replace('LocalTime end = LocalTime.parse(endF.getText().trim());', 'LocalTime end = LocalTime.parse(endF.getText().trim(), DateTimeFormatter.ofPattern("HH.mm"));')

# 4. Group Session Panel
# Remove levelCB
content = re.sub(r'JComboBox<Member\.MemberType> levelCB = new JComboBox<>\(Member\.MemberType\.values\(\)\);\s*', '', content)
content = content.replace('createRow.add(new JLabel("Min Level:")); createRow.add(levelCB);', '')
# Change constructor call
content = content.replace('new GroupSessionEvent(room, (Member.MemberType) levelCB.getSelectedItem(), start, end, date, (GroupSessionEvent.SessionType) sessionCB.getSelectedItem())', 'new GroupSessionEvent(room, start, end, date, (GroupSessionEvent.SessionType) sessionCB.getSelectedItem())')
# Refresh combo boxes with filter
content = content.replace('refreshComboBoxes(roomCB, memberCB, null);', 'refreshComboBoxes(roomCB, memberCB, null, "GroupSessionRoom", null);')

# 5. Gym Bookings Panel
content = content.replace('new GymEvent(room, Member.MemberType.BASIC, start, end, date, m)', 'new GymEvent(room, start, end, date, m)')
content = content.replace('refreshComboBoxes(roomCB, memberCB, null);', 'refreshComboBoxes(roomCB, memberCB, null, "GymRoom", null);')

# 6. Trainer Sessions Panel
content = content.replace('refreshComboBoxes(roomCB, memberCB, trainerCB);', 'refreshComboBoxes(roomCB, memberCB, trainerCB, "GymRoom", Member.MemberType.VIP);')

# 7. Workout Panel
content = content.replace('refreshComboBoxes(null, memberCB, null);', 'refreshComboBoxes(null, memberCB, null, null, null);')

# Dates & Times parsing for all
content = content.replace('Date (YYYY-MM-DD):', 'Date (DD,MM,YYYY):')
content = content.replace('Date:', 'Date (DD,MM,YYYY):') # in Gym & Trainer & Workout
# fix "Date (DD,MM,YYYY):" being replaced again if I do it twice
content = content.replace('Date (DD,MM,YYYY): (DD,MM,YYYY):', 'Date (DD,MM,YYYY):') 
content = content.replace('Use YYYY-MM-DD format', 'Use DD,MM,YYYY format')
content = content.replace('LocalDate date = LocalDate.parse(dateF.getText().trim());', 'LocalDate date = LocalDate.parse(dateF.getText().trim(), DateTimeFormatter.ofPattern("dd,MM,yyyy"));')
# Make sure Date formatting for display is correct, but let's just stick to parsing first. The assignment specifically asked for "format should be HH.MM and date format should be DD,MM,YYYY."
# We should probably format the dates in tables too? Yes.
# "e.getDate()" -> "e.getDate().format(DateTimeFormatter.ofPattern(\"dd,MM,yyyy\"))"
content = re.sub(r'e\.getDate\(\)', 'e.getDate().format(DateTimeFormatter.ofPattern("dd,MM,yyyy"))', content)
content = re.sub(r'log\.getDate\(\)', 'log.getDate().format(DateTimeFormatter.ofPattern("dd,MM,yyyy"))', content)


# 8. Helper Methods update
old_refresh = """    private void refreshComboBoxes(JComboBox<String> roomCB, JComboBox<String> memberCB, JComboBox<String> trainerCB) {
        if (roomCB != null) {
            roomCB.removeAllItems();
            for (Room r : management.getRooms()) roomCB.addItem(r.getId() + ": " + r.toString());
        }
        if (memberCB != null) {
            memberCB.removeAllItems();
            for (Member m : management.getMembers()) memberCB.addItem(m.getId() + ": " + m.toString());
        }
        if (trainerCB != null) {
            trainerCB.removeAllItems();
            for (PersonalTrainer t : management.getTrainers()) trainerCB.addItem(t.getId() + ": " + t.toString());
        }
    }"""

new_refresh = """    private void refreshComboBoxes(JComboBox<String> roomCB, JComboBox<String> memberCB, JComboBox<String> trainerCB, String roomFilter, Member.MemberType memberFilter) {
        if (roomCB != null) {
            roomCB.removeAllItems();
            for (Room r : management.getRooms()) {
                if (roomFilter == null || 
                   (roomFilter.equals("GymRoom") && r instanceof GymRoom) || 
                   (roomFilter.equals("GroupSessionRoom") && r instanceof GroupSessionRoom)) {
                    roomCB.addItem(r.getId() + ": " + r.toString());
                }
            }
        }
        if (memberCB != null) {
            memberCB.removeAllItems();
            for (Member m : management.getMembers()) {
                if (memberFilter == null || m.getMembershipType() == memberFilter) {
                    memberCB.addItem(m.getId() + ": " + m.toString());
                }
            }
        }
        if (trainerCB != null) {
            trainerCB.removeAllItems();
            for (PersonalTrainer t : management.getTrainers()) {
                trainerCB.addItem(t.getId() + ": " + t.toString());
            }
        }
    }"""
content = content.replace(old_refresh, new_refresh)

# Fix double occurrences if any
content = content.replace('Date (DD,MM,YYYY): (DD,MM,YYYY):', 'Date (DD,MM,YYYY):')
content = content.replace('Date (DD,MM,YYYY):', 'Date (DD,MM,YYYY):') # just to be safe

# Add import for GroupSessionRoom
content = content.replace('import org.NonDetermenisticTeam.actors.*;', 'import org.NonDetermenisticTeam.actors.*;\nimport org.NonDetermenisticTeam.actors.GroupSessionRoom;')

with open(r"c:\Users\ehank\Desktop\NonDetermenisticGym\src\main\java\org\NonDetermenisticTeam\GymUI.java", "w") as f:
    f.write(content)

print("Update complete")
